package com.example.expensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ExpenseDBHelper dbHelper;
    List<Expense> expenses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new ExpenseDBHelper(this);
        listView = findViewById(R.id.expenseList);
        Button addButton = findViewById(R.id.addExpenseButton);

        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddExpenseActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        expenses = dbHelper.getAllExpenses();
        ExpenseAdapter adapter = new ExpenseAdapter(this, expenses);
        listView.setAdapter(adapter);
    }
}