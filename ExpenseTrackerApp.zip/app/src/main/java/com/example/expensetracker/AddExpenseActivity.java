package com.example.expensetracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddExpenseActivity extends AppCompatActivity {

    EditText titleInput, amountInput, dateInput;
    Button saveBtn;
    ExpenseDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        titleInput = findViewById(R.id.expenseTitle);
        amountInput = findViewById(R.id.expenseAmount);
        dateInput = findViewById(R.id.expenseDate);
        saveBtn = findViewById(R.id.saveExpenseBtn);

        dbHelper = new ExpenseDBHelper(this);

        saveBtn.setOnClickListener(view -> {
            String title = titleInput.getText().toString();
            double amount = Double.parseDouble(amountInput.getText().toString());
            String date = dateInput.getText().toString();

            dbHelper.insertExpense(title, amount, date);
            Toast.makeText(this, "Expense Added", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}